function wua(){
  $(".visible-windows-block").css("display","block");
  $(".visible-windows-inline").css("display","inline");
  $(".hidden-windows").css("display","none");
}
function mua(){
  $(".visible-macintosh-block").css("display","block");
  $(".visible-macintosh-inline").css("display","inline");
  $(".hidden-macintosh").css("display","none");
}
function lua(){
  $(".visible-linux-block").css("display","block");
  $(".visible-linux-inline").css("display","inline");
  $(".hidden-linux").css("display","none");
}
function moua(){
  $(".visible-mobile-block").css("display","block");
  $(".visible-mobile-inline").css("display","inline");
  $(".hidden-mobile").css("display","none");
}
if (navigator.userAgent.indexOf('Windows NT') > 0) {wua();}
if (navigator.userAgent.indexOf('Macintosh') > 0) {mua();}
if (navigator.userAgent.indexOf('Linux') > 0 && navigator.userAgent.indexOf('Android') < 0) {lua();}
if (navigator.userAgent.indexOf('iPhone') > 0 || navigator.userAgent.indexOf('iPad') > 0 || navigator.userAgent.indexOf('iPod') > 0 || navigator.userAgent.indexOf('Android') > 0 || navigator.userAgent.indexOf('Windows Phone') > 0) {moua();$('#dlbtn').attr("disabled","");}
function rmf1(){$("#btn1").removeClass("focus");}
function rmf2(){$("#btn2").removeClass("focus");}
function rmf3(){$("#btn3").removeClass("focus");}
function wbtn(){
  $(".visible-macintosh-block,.visible-linux-block,.visible-macintosh-inline,.visible-linux-inline").css("display","none");
  wua();rmf2();rmf3();
  $("#btn1").addClass("focus");
}
function mbtn(){
  $(".visible-windows-block,.visible-linux-block,.visible-windows-inline,.visible-linux-inline").css("display","none");
  mua();rmf1();rmf3();
  $("#btn2").addClass("focus");
}
function lbtn(){
  $(".visible-windows-block,.visible-macintosh-block,.visible-windows-inline,.visible-macintosh-inline").css("display","none");
  lua();rmf1();rmf2();
  $("#btn3").addClass("focus");
}
function mobtn(){
  if (navigator.userAgent.indexOf('iPhone') > 0 || navigator.userAgent.indexOf('iPad') > 0 || navigator.userAgent.indexOf('iPod') > 0 || navigator.userAgent.indexOf('Android') > 0 || navigator.userAgent.indexOf('Windows Phone') > 0) {wbtn();}
}
